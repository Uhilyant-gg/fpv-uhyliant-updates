import argparse,json,os,sys,time
from pathlib import Path

def self_test(app_dir):
 required=['Main.qml','backend.py','updater_engine.py'];missing=[x for x in required if not (app_dir/x).exists()]
 print(json.dumps({'status':'ok' if not missing else 'error','missing':missing,'version':'1.4.0'}));return 0 if not missing else 2

def signal_startup_ok(token):
 if not token:return
 data=Path(os.environ.get('LOCALAPPDATA',Path.home()))/'FPV-Uhyliant';data.mkdir(parents=True,exist_ok=True)
 tmp=data/'startup-ok.tmp';dst=data/'startup-ok.json'
 tmp.write_text(json.dumps({'status':'ok','token':token,'version':'1.4.0','time':time.time()}),encoding='utf-8');os.replace(tmp,dst)

def main():
 ap=argparse.ArgumentParser(add_help=False);ap.add_argument('--self-test',action='store_true');ap.add_argument('--install-root');ap.add_argument('--startup-token');args,_=ap.parse_known_args();here=Path(__file__).resolve().parent
 if args.self_test:return self_test(here)
 from PySide6.QtCore import QUrl,QTimer
 from PySide6.QtGui import QGuiApplication
 from PySide6.QtQml import QQmlApplicationEngine
 from PySide6.QtQuickControls2 import QQuickStyle
 from backend import Station
 from updater_engine import Updater
 app=QGuiApplication(sys.argv);app.setApplicationName('ФПВ Ухилянт');QQuickStyle.setStyle('Basic');engine=QQmlApplicationEngine();station=Station();updater=Updater(args.install_root,station.canInstallUpdate)
 engine.rootContext().setContextProperty('station',station);engine.rootContext().setContextProperty('updater',updater);engine.load(QUrl.fromLocalFile(str(here/'Main.qml')))
 if not engine.rootObjects():return 1
 # Handshake only after the QML root exists and the event loop has started.
 QTimer.singleShot(1200,lambda:signal_startup_ok(args.startup_token))
 return app.exec()
if __name__=='__main__':raise SystemExit(main())
