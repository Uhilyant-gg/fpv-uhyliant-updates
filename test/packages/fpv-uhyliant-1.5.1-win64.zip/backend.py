from PySide6.QtCore import QObject, Property, Signal, Slot

class Station(QObject):
    changed=Signal();notice=Signal(str)
    def __init__(self):
        super().__init__();self._menu=False;self._updater=False;self._osd=True;self._video=False;self._armed=False;self._recording=False;self._streaming=False
    @Property(bool,notify=changed)
    def menuOpen(self):return self._menu
    @Property(bool,notify=changed)
    def updaterOpen(self):return self._updater
    @Property(bool,notify=changed)
    def osdVisible(self):return self._osd
    @Property(bool,notify=changed)
    def videoRunning(self):return self._video
    @Slot()
    def toggleMenu(self):self._menu=not self._menu;self.changed.emit()
    @Slot()
    def openUpdater(self):self._menu=False;self._updater=True;self.changed.emit()
    @Slot()
    def closeUpdater(self):self._updater=False;self.changed.emit()
    @Slot()
    def toggleOSD(self):self._osd=not self._osd;self.changed.emit()
    @Slot()
    def toggleVideo(self):self._video=not self._video;self.changed.emit();self.notice.emit('Відео увімкнено' if self._video else 'Відео зупинено')
    def canInstallUpdate(self):
        reasons=[]
        if self._armed:reasons.append("автопілот озброєний")
        if self._recording:reasons.append("активний запис")
        if self._streaming:reasons.append("активна трансляція")
        return (not reasons,"Неможливо оновити: "+", ".join(reasons) if reasons else "")
    @Slot(str)
    def action(self,text):self.notice.emit(text)
