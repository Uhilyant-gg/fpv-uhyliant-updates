import hashlib, json, os, urllib.request, subprocess, sys, base64
from pathlib import Path
from PySide6.QtCore import QObject, Property, Signal, Slot, QThread
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature

APP_VERSION = "1.0.0"
DATA_ROOT = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "FPV-Uhyliant"
UPDATE_ROOT = DATA_ROOT / "updates"
CONFIG_FILE = DATA_ROOT / "updater.json"

PUBLIC_KEY_PATH = Path(__file__).resolve().parent / "security" / "release-public-key.pem"
EXPECTED_KEY_ID = "fpv-uhyliant-test-2026"

def canonical_manifest(obj):
    unsigned=dict(obj);unsigned.pop("signature",None)
    return json.dumps(unsigned,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")

def verify_manifest_signature(obj):
    sig=obj.get("signature") or {}
    if sig.get("algorithm")!="Ed25519":raise RuntimeError("Unsupported or missing manifest signature")
    if sig.get("keyId")!=EXPECTED_KEY_ID:raise RuntimeError("Untrusted manifest signing key")
    if not PUBLIC_KEY_PATH.is_file():raise RuntimeError("Pinned update public key is missing")
    try:
        signature=base64.b64decode(sig.get("value",""),validate=True)
        key=serialization.load_pem_public_key(PUBLIC_KEY_PATH.read_bytes())
        key.verify(signature,canonical_manifest(obj))
    except (InvalidSignature,ValueError,TypeError) as e:
        raise RuntimeError("Manifest signature verification failed") from e
    return True

def version_tuple(value):
    return tuple(int(x) if x.isdigit() else 0 for x in value.split("-")[0].split("."))

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""): h.update(block)
    return h.hexdigest()

class Worker(QThread):
    progress=Signal(int,str);done=Signal(bool,object)
    def __init__(self,action,payload):super().__init__();self.action=action;self.payload=payload
    def run(self):
        try:
            if self.action=="check":
                with urllib.request.urlopen(self.payload["url"],timeout=15) as r: raw=r.read(2*1024*1024)
                m=json.loads(raw.decode("utf-8"))
                verify_manifest_signature(m)
                for k in ("product","channel","version","build","package"):
                    if k not in m:raise RuntimeError("Invalid manifest: "+k)
                if m["product"]!="FPV-Uhyliant":raise RuntimeError("Unexpected product")
                self.progress.emit(100,"Metadata verified");self.done.emit(True,m)
            else:
                m=self.payload["manifest"];pkg=m["package"];UPDATE_ROOT.mkdir(parents=True,exist_ok=True)
                target=UPDATE_ROOT/pkg["file"];offset=target.stat().st_size if target.exists() else 0
                req=urllib.request.Request(pkg["url"])
                if offset:req.add_header("Range",f"bytes={offset}-")
                mode="ab" if offset else "wb"
                with urllib.request.urlopen(req,timeout=30) as r,open(target,mode) as f:
                    total=offset+int(r.headers.get("Content-Length") or 0);done=offset
                    while True:
                        block=r.read(524288)
                        if not block:break
                        f.write(block);done+=len(block);self.progress.emit(int(done*100/total) if total else 0,f"{done//1048576} MB")
                actual=sha256_file(target);expected=pkg.get("sha256","").lower()
                if not expected or actual.lower()!=expected:target.unlink(missing_ok=True);raise RuntimeError("SHA-256 mismatch")
                ready={"version":m["version"],"package":str(target),"sha256":actual}
                (UPDATE_ROOT/"ready.json").write_text(json.dumps(ready,indent=2),encoding="utf-8")
                self.done.emit(True,ready)
        except Exception as e:self.done.emit(False,str(e))

class Updater(QObject):
    changed=Signal();progressChanged=Signal()
    def __init__(self, install_root=None, can_install=None):
        super().__init__();DATA_ROOT.mkdir(parents=True,exist_ok=True)
        self._install_root=Path(install_root).resolve() if install_root else None
        self._can_install=can_install or (lambda:(True,""))
        cfg={"channel":"test","manifestUrl":""}
        if CONFIG_FILE.exists():
            try:cfg.update(json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
            except:pass
        self._channel=cfg["channel"];self._url=cfg["manifestUrl"];self._state="idle";self._progress=0;self._status="Готово";self._available="";self._notes=[];self._manifest={};self._worker=None
    @Property(str,constant=True)
    def currentVersion(self):return APP_VERSION
    @Property(str,notify=changed)
    def channel(self):return self._channel
    @Property(str,notify=changed)
    def manifestUrl(self):return self._url
    @Property(str,notify=changed)
    def state(self):return self._state
    @Property(str,notify=changed)
    def status(self):return self._status
    @Property(str,notify=changed)
    def availableVersion(self):return self._available
    @Property('QStringList',notify=changed)
    def releaseNotes(self):return self._notes
    @Property(int,notify=progressChanged)
    def progress(self):return self._progress
    @Slot(str,str)
    def configure(self,channel,url):
        self._channel=channel;self._url=url.strip();CONFIG_FILE.write_text(json.dumps({"channel":channel,"manifestUrl":self._url},indent=2),encoding="utf-8");self.changed.emit()
    @Slot()
    def check(self):
        if not self._url:self._state="error";self._status="Вкажіть Manifest URL";self.changed.emit();return
        self._start("check",{"url":self._url},"Перевірка оновлень")
    @Slot()
    def download(self):
        if self._manifest:self._start("download",{"manifest":self._manifest},"Завантаження")
    @Property(bool,notify=changed)
    def installReady(self):return self._state=="ready" and (UPDATE_ROOT/"ready.json").exists() and self._install_root is not None
    @Slot()
    def installNow(self):
        ok,reason=self._can_install()
        if not ok:self._state="blocked";self._status=reason or "Установка заблокована активною сесією";self.changed.emit();return
        ready_file=UPDATE_ROOT/"ready.json"
        if not self._install_root or not ready_file.exists():self._state="error";self._status="Немає готового пакета або install root";self.changed.emit();return
        ready=json.loads(ready_file.read_text(encoding="utf-8"));helper=self._install_root/"update_helper.py"
        if not helper.exists():self._state="error";self._status="update_helper.py не знайдено";self.changed.emit();return
        cmd=[sys.executable,str(helper),"--root",str(self._install_root),"--package",ready["package"],"--version",ready["version"],"--wait-pid",str(os.getpid())]
        subprocess.Popen(cmd,cwd=str(self._install_root),creationflags=getattr(subprocess,"CREATE_NEW_PROCESS_GROUP",0)|getattr(subprocess,"DETACHED_PROCESS",0))
        self._state="installing";self._status="Станція закривається для атомарного оновлення";self.changed.emit()
        from PySide6.QtCore import QCoreApplication,QTimer
        QTimer.singleShot(300,QCoreApplication.quit)
    def _start(self,action,payload,status):
        self._state=action;self._status=status;self._progress=0;self.changed.emit();self.progressChanged.emit();self._worker=Worker(action,payload);self._worker.progress.connect(self._progressed);self._worker.done.connect(lambda ok,data:self._done(action,ok,data));self._worker.start()
    def _progressed(self,p,text):self._progress=p;self._status=text;self.progressChanged.emit();self.changed.emit()
    def _done(self,action,ok,data):
        if not ok:self._state="error";self._status=str(data);self.changed.emit();return
        if action=="check":
            self._manifest=data
            if data["channel"]!=self._channel:self._state="error";self._status="Канал manifest не збігається"
            elif version_tuple(data["version"])>version_tuple(APP_VERSION):self._state="available";self._available=data["version"];self._notes=data.get("releaseNotes",[]);self._status="Оновлення доступне"
            else:self._state="current";self._status="Версія актуальна"
        else:self._state="ready";self._status="Пакет перевірено. Install/rollback буде в наступному етапі."
        self.changed.emit()
