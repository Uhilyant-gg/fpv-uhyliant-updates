import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

ApplicationWindow {
    id:w; width:1600; height:950; minimumWidth:1180; minimumHeight:720; visible:true
    title:"ФПВ Ухилянт v1.4 — Startup-OK Rollback"; color:"#050b12"
    property color panel:"#df0b1725"; property color line:"#27405d"; property color txt:"#f4f7fb"; property color muted:"#8fa2ba"; property color blue:"#42a0ff"; property color green:"#24d18f"; property color red:"#ff6374"; property color amber:"#f5c65b"
    property bool chrome:true
    Shortcut{sequence:"F11";onActivated:{chrome=!chrome;w.visibility=chrome?Window.Maximized:Window.FullScreen}}
    Shortcut{sequence:"Escape";onActivated:{chrome=true;w.visibility=Window.Maximized;if(station.updaterOpen)station.closeUpdater()}}
    Shortcut{sequence:"F2";onActivated:station.toggleVideo()}

    component HudPanel: Rectangle { color:w.panel; radius:9; border.color:w.line; border.width:1 }
    component MenuButton: Button {
        implicitHeight:43; Layout.fillWidth:true
        background:Rectangle{color:parent.hovered?"#19344f":"transparent";radius:7}
        contentItem:Text{text:parent.text;color:w.txt;font.pixelSize:14;verticalAlignment:Text.AlignVCenter;leftPadding:11}
    }

    header: Rectangle {
        visible:chrome; height:74; color:"#07111b"; border.color:"#14293f"
        RowLayout{anchors.fill:parent;anchors.leftMargin:18;anchors.rightMargin:18;spacing:10
            ColumnLayout{Layout.preferredWidth:300;spacing:0
                Text{text:"ФПВ УХИЛЯНТ";color:w.txt;font.pixelSize:24;font.bold:true}
                Text{text:"НАЗЕМНА СТАНЦІЯ КЕРУВАННЯ  •  v1.4";color:w.muted;font.pixelSize:10}
            }
            RowLayout{Layout.fillWidth:true;spacing:6
                Rectangle{width:74;height:48;radius:8;color:"#0c4638";Text{anchors.centerIn:parent;text:"AUTO\nРЕЖИМ";horizontalAlignment:Text.AlignHCenter;color:w.green;font.bold:true}}
                Repeater{model:["1\n1.5M","2\n1.2M","3\n1M","4\n800k","5\n700k","6\n500k","7\n350k","8\n250k","9\n150k","0\nКОР."]
                    delegate:Rectangle{required property string modelData;width:58;height:48;radius:7;color:index===0?"#125cb4":"#101e2d";border.color:index===0?w.blue:w.line;Text{anchors.centerIn:parent;text:modelData;horizontalAlignment:Text.AlignHCenter;color:w.txt;font.pixelSize:12}}
                }
            }
            ColumnLayout{spacing:1;Text{text:"●  Зв’язок OK";color:w.green;font.bold:true}Text{text:"IPv6  34 ms  •  loss 0.2%  •  jitter 4 ms";color:w.muted;font.pixelSize:10}}
            Text{text:"18:24:17\n20.11.2026";horizontalAlignment:Text.AlignRight;color:w.txt;font.pixelSize:13}
            Button{text:"☰";font.pixelSize:25;onClicked:station.toggleMenu();background:Rectangle{color:"#101e2d";border.color:w.blue;radius:9};contentItem:Text{text:parent.text;color:w.txt;font.pixelSize:25;horizontalAlignment:Text.AlignHCenter;verticalAlignment:Text.AlignVCenter}}
        }
    }

    Item{
        anchors.fill:parent
        Image{anchors.fill:parent;source:"preview_flight.jpg";fillMode:Image.PreserveAspectCrop;opacity:station.videoRunning?1:.32}
        Rectangle{anchors.fill:parent;color:station.videoRunning?"transparent":"#b0020609"}
        Text{visible:!station.videoRunning;anchors.centerIn:parent;text:"FPV ВІДЕО\nF2 • Увімкнути відео";horizontalAlignment:Text.AlignHCenter;color:w.muted;font.pixelSize:25;font.bold:true}

        Item{visible:station.osdVisible;anchors.fill:parent
            Row{anchors.left:parent.left;anchors.top:parent.top;anchors.margins:18;spacing:8
                HudPanel{width:145;height:42;Row{anchors.centerIn:parent;spacing:8;Rectangle{width:10;height:10;radius:5;color:w.red}Text{text:"REC 00:12:46";color:w.txt;font.bold:true}}}
                HudPanel{width:300;height:42;Text{anchors.centerIn:parent;text:"1080p   H.265   30 FPS   1.5 Mbps";color:w.txt}}
            }
            HudPanel{width:500;height:44;anchors.horizontalCenter:parent.horizontalCenter;anchors.top:parent.top;anchors.topMargin:16;Text{anchors.centerIn:parent;text:"W     300     330       348 N       15     30     NE";color:w.txt;font.family:"Consolas";font.pixelSize:16;font.bold:true}}
            Column{anchors.left:parent.left;anchors.verticalCenter:parent.verticalCenter;anchors.leftMargin:22;spacing:8
                Repeater{model:["ALT\n124 m","SPD\n12.4 m/s","VSPD\n-0.3 m/s"]
                    delegate:HudPanel{required property string modelData;width:150;height:76;opacity:.70;Text{anchors.fill:parent;anchors.margins:12;text:modelData;color:w.txt;font.pixelSize:16;font.bold:true}}
                }
            }
            Item{width:72;height:72;anchors.centerIn:parent;Rectangle{width:52;height:2;color:"white";anchors.centerIn:parent}Rectangle{width:2;height:52;color:"white";anchors.centerIn:parent}Rectangle{width:8;height:8;radius:4;color:"#050b12";border.color:"white";anchors.centerIn:parent}}
            HudPanel{width:190;height:102;anchors.left:parent.left;anchors.bottom:parent.bottom;anchors.margins:22;opacity:.73;Column{anchors.centerIn:parent;spacing:6;Text{text:"▣  62%";color:w.txt;font.pixelSize:23;font.bold:true}Text{text:"15.8 V    22.4 A    354 W";color:w.txt}Text{text:"RSSI 87   •   35°C";color:w.muted}}}
            HudPanel{width:230;height:108;anchors.horizontalCenter:parent.horizontalCenter;anchors.bottom:parent.bottom;anchors.bottomMargin:20;opacity:.73;Row{anchors.centerIn:parent;spacing:20;Column{Text{text:"✈ POSHOLD";color:w.blue;font.pixelSize:17;font.bold:true}Text{text:"Режим";color:w.muted}}Column{Text{text:"▣ РОЗЗБРОЄНО";color:w.amber;font.pixelSize:17;font.bold:true}Text{text:"Озброєння";color:w.muted}}}}
            HudPanel{width:220;height:102;anchors.right:parent.right;anchors.bottom:parent.bottom;anchors.rightMargin:22;anchors.bottomMargin:22;opacity:.73;Column{anchors.centerIn:parent;spacing:5;Text{text:"GPS 3D | 18";color:w.txt;font.bold:true}Text{text:"HDOP 0.8   Home 1.2 km";color:w.muted}Text{text:"IPv6 • 34 ms • loss 0.2%";color:w.green}}}
        }

        HudPanel{
            visible:station.menuOpen;z:20;width:330;height:640;anchors.right:parent.right;anchors.top:parent.top;anchors.margins:14
            ColumnLayout{anchors.fill:parent;anchors.margins:14;spacing:3
                Text{text:"МЕНЮ СТАНЦІЇ";color:w.txt;font.pixelSize:16;font.bold:true;Layout.leftMargin:8}
                Rectangle{Layout.fillWidth:true;height:1;color:w.line}
                MenuButton{text:"▣  Пристрої"} MenuButton{text:"●  Камера"} MenuButton{text:"◇  Карта"} MenuButton{text:"⌁  Діагностика"} MenuButton{text:"⇧  Прошивка"} MenuButton{text:"✦  Інженер (AI)"} MenuButton{text:"⚙  Налаштування"}
                Rectangle{Layout.fillWidth:true;height:1;color:w.line}
                MenuButton{text:"◉  OSD";onClicked:station.toggleOSD()} MenuButton{text:"↗  Стрім у мережу"} MenuButton{text:"●  Запис відео"}
                Rectangle{Layout.fillWidth:true;height:1;color:w.line}
                MenuButton{text:"⬆  Оновлення станції";onClicked:station.openUpdater()}
                MenuButton{text:"⛶  Повний екран   F11";onClicked:{chrome=false;w.visibility=Window.FullScreen;station.toggleMenu()}}
                Item{Layout.fillHeight:true}
                MenuButton{text:"⏻  Вихід";onClicked:Qt.quit()}
            }
        }
    }

    Popup{
        id:updatePopup;visible:station.updaterOpen;modal:true;closePolicy:Popup.CloseOnEscape|Popup.CloseOnPressOutside;anchors.centerIn:Overlay.overlay;width:Math.min(700,w.width-40);height:650;onClosed:station.closeUpdater()
        background:Rectangle{color:"#101c2c";border.color:w.blue;radius:14}
        contentItem:ColumnLayout{anchors.fill:parent;anchors.margins:22;spacing:12
            RowLayout{Layout.fillWidth:true;ColumnLayout{Layout.fillWidth:true;Text{text:"ОНОВЛЕННЯ СТАНЦІЇ";color:w.txt;font.pixelSize:22;font.bold:true}Text{text:"Вбудовано в наземну станцію";color:w.muted}}Button{text:"✕";onClicked:updatePopup.close()}}
            Rectangle{Layout.fillWidth:true;height:1;color:w.line}
            GridLayout{columns:2;columnSpacing:18;rowSpacing:10;Layout.fillWidth:true
                Text{text:"Поточна версія";color:w.muted}Text{text:updater.currentVersion;color:w.txt;font.bold:true}
                Text{text:"Доступна версія";color:w.muted}Text{text:updater.availableVersion||"--";color:w.green;font.bold:true}
                Text{text:"Канал";color:w.muted}ComboBox{id:channel;model:["test","stable","development"];currentIndex:Math.max(0,model.indexOf(updater.channel));Layout.fillWidth:true}
                Text{text:"Manifest URL";color:w.muted}TextField{id:url;text:updater.manifestUrl;placeholderText:"https://server/test/release.json";Layout.fillWidth:true}
            }
            RowLayout{Layout.fillWidth:true;Button{text:"Зберегти";onClicked:updater.configure(channel.currentText,url.text)}Button{text:"Перевірити";onClicked:updater.check()}Item{Layout.fillWidth:true}Text{text:updater.status;color:updater.state==="error"?w.red:w.muted;wrapMode:Text.WordWrap;Layout.preferredWidth:320}}
            ProgressBar{from:0;to:100;value:updater.progress;Layout.fillWidth:true;visible:updater.state==="check"||updater.state==="download"}
            Text{text:"Що нового";color:w.txt;font.pixelSize:17;font.bold:true}
            ListView{Layout.fillWidth:true;Layout.fillHeight:true;clip:true;model:updater.releaseNotes;delegate:Text{required property string modelData;width:ListView.view.width;text:"•  "+modelData;color:w.txt;font.pixelSize:14;wrapMode:Text.WordWrap;padding:6}}
            Rectangle{Layout.fillWidth:true;height:1;color:w.line}
            Text{text:"Launcher виконає self-test, атомарно перемкне current/previous і автоматично поверне попередню версію при помилці.";color:w.amber;wrapMode:Text.WordWrap;Layout.fillWidth:true}
            RowLayout{Layout.fillWidth:true;Button{text:"Завантажити пакет";enabled:updater.state==="available";onClicked:updater.download()}Item{Layout.fillWidth:true}Button{text:"Оновити та перезапустити";enabled:updater.installReady;onClicked:updater.installNow()}}
        }
    }
}
